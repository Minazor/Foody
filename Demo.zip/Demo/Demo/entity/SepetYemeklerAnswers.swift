import Foundation
class SepetYemeklerAnswers: Codable {
    var sepet_yemekler: [SepetYemekler]?
    var success: Int?
}
