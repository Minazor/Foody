import Foundation

class YemeklerAnswers : Codable {
    var yemekler:[Yemekler]?
    var success:Int?
}

