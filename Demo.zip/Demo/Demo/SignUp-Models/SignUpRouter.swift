
import Foundation

class SignUpRouter: PresenterToRouterSignUpProtocol {
    
    static func createModule(ref: SignUpVC) {
        ref.signUpPresenterObj = SignUpPresenter()
        ref.signUpPresenterObj?.signUpInteractor = SignUpInteractor()
    }
}
