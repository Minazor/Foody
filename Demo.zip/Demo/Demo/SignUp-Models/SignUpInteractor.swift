import Foundation
import FirebaseAuth

class SignUpInteractor: PresenterToInteractorSignUpProtocol {
    
    
    func signUp(email: String, password: String) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            
            if error != nil {
                print(String(describing: error))
            }
            
        }
    }
}

