import Foundation

class SignUpPresenter: ViewToPresenterSignUpProtocol {
   
    var signUpInteractor: PresenterToInteractorSignUpProtocol?
    
    func signUp(email: String, password: String){
        signUpInteractor?.signUp(email: email, password: password)
    }
}
