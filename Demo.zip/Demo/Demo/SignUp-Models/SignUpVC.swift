import UIKit
import FirebaseAuth

class SignUpVC: UIViewController {

    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfSifre: UITextField!
    @IBOutlet weak var tfSifreTekrar: UITextField!
    
    var signUpPresenterObj: ViewToPresenterSignUpProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SignUpRouter.createModule(ref: self)
        tfSifre.autocorrectionType = .no
        tfSifreTekrar.autocorrectionType = .no
    }
    @IBAction func signUp(_ sender: Any) {
        if let email = tfEmail.text, let password = tfSifre.text, let controlPassword = tfSifreTekrar.text{
            if password == controlPassword {
                signUpPresenterObj?.signUp(email: email, password: password)
                let allertController = UIAlertController(title: "Üyelik tamamlandı", message: "Giriş yapabilirsiniz :)", preferredStyle: .actionSheet)
                
                let okayAction = UIAlertAction(title: "Giriş yap", style: .destructive){
                    action in
                    let presentingController = self.presentingViewController
                    self.dismiss(animated: true) {
                        if let navigationController = presentingController as? UINavigationController,
                           let myDownloadsViewController = navigationController.viewControllers.first(
                               where: { viewController in
                                   viewController is SignUpVC
                               }
                           ) {
                           navigationController.popToViewController(myDownloadsViewController, animated: true)
                        }
                    }
                }
                allertController.addAction(okayAction)
                self.present(allertController, animated: true)
            }
        }
    }
    
}
