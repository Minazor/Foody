import Foundation
protocol ViewToPresenterSignUpProtocol {
    
    var signUpInteractor: PresenterToInteractorSignUpProtocol? { get set }
    func signUp(email: String, password: String)
}

protocol PresenterToInteractorSignUpProtocol {
    func signUp(email: String, password: String)

}

protocol PresenterToRouterSignUpProtocol {
    
    static func createModule(ref: SignUpVC)
}
