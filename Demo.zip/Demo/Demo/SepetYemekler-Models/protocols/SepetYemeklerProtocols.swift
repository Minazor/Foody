import Foundation

protocol ViewToPresenterSepetYemeklerProtocol {
    var sepetYemeklerInteractor:PresenterToInteractorSepetYemeklerProtocol? {get set}
    var sepetYemeklerView:PresenterToViewSepetYemeklerProtocol? {get set}
    
    func getSepetYemekler(kullanici_adi:String)
    func delete(sepet_yemek_id:Int,kullanici_adi:String)
    func adetArttir(yemek: SepetYemekler)
    func adetAzalt(yemek: SepetYemekler)
    func deleteTumSepet(list: [SepetYemekler])
  
}

protocol PresenterToInteractorSepetYemeklerProtocol {
    var sepetYemeklerPresenter:InteractorToPresenterSepetYemeklerProtocol? {get set}
    
    func getTumSepetYemekler(kullanici_adi:String)
    func deleteSepetYemek(sepet_yemek_id:Int,kullanici_adi:String)
    func adetArttir(yemek: SepetYemekler)
    func adetAzalt(yemek: SepetYemekler)
    func deleteTumSepet(list: [SepetYemekler])

}


protocol InteractorToPresenterSepetYemeklerProtocol{
    func presenteraVeriGonder(sepetYemeklerListesi:[SepetYemekler])
}

protocol PresenterToViewSepetYemeklerProtocol {
    func vieweVeriGonder(sepetYemeklerListesi:[SepetYemekler])
}

protocol PresenterToRouterSepetYemeklerProtocol{
    static func createModule(ref:SepetYemeklerVC)
}
protocol CellProtocol {
    func adetArttir(indexPath: IndexPath)
    func adetAzalt(indexPath: IndexPath)

}
