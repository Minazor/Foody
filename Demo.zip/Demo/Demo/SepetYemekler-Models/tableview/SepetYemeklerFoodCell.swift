import UIKit
class SepetYemeklerFoodCell: UITableViewCell {
    
    @IBOutlet weak var sepetYemekName: UILabel!
    @IBOutlet weak var sepetYemekPrice: UILabel!
    @IBOutlet weak var sepetYemekImage: UIImageView!
    @IBOutlet weak var sepetYemekAdet: UILabel!
    var cellpro: CellProtocol?
    var indexPath: IndexPath?
    
    @IBOutlet weak var azaltButton: UIButton!
    func fetchData(yemek: SepetYemekler) {
        
        let url = URL (string: ("http://kasimadalan.pe.hu/yemekler/resimler/\(yemek.yemek_resim_adi!)"))
        sepetYemekImage.kf.setImage(with: url)
        sepetYemekName.text = yemek.yemek_adi!
        sepetYemekPrice.text = yemek.yemek_fiyat!
        sepetYemekAdet.text = yemek.yemek_siparis_adet!
    }
    
    @IBAction func azalt(_ sender: Any) {
        cellpro?.adetAzalt(indexPath: indexPath!)
    }
    @IBAction func arttir(_ sender: Any) {
        cellpro?.adetArttir(indexPath: indexPath!)
    }
}
