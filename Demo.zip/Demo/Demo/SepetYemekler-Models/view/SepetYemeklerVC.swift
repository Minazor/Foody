import UIKit
import Kingfisher
import FirebaseAuth

class SepetYemeklerVC: UIViewController {

    @IBOutlet weak var sepetYemeklerTableView: UITableView!
    var sepetYemeklerListesi: [SepetYemekler] = []
    var sepetYemeklerPresenterObj:ViewToPresenterSepetYemeklerProtocol?
    
    @IBOutlet weak var labelPrice: UILabel!
    
    var price = 0
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        sepetYemeklerTableView.delegate = self
        sepetYemeklerTableView.dataSource = self
        
        labelPrice.text = String(price)
        
        
        SepetYemeklerRouter.createModule(ref: self)
    }
    override func viewWillAppear(_ animated: Bool) {
        
        let username = Auth.auth().currentUser!.email
        sepetYemeklerPresenterObj?.getSepetYemekler(kullanici_adi: username!)
    }
    func toplamHesapla() {
        price = 0
        for yemek in sepetYemeklerListesi {
            price = price + (Int(yemek.yemek_fiyat!)! * Int(yemek.yemek_siparis_adet!)!)
        }
        labelPrice.text = "\(String(price)) ₺"
    }
    @IBAction func satinAlButton(_ sender: Any) {
        let allertController = UIAlertController(title: "Siparişiniz Alındı!", message: "Onaylıyor musunuz?", preferredStyle: .actionSheet)
       
        let cancelAction = UIAlertAction(title: "İptal", style: .cancel){
            action in
        }
        allertController.addAction(cancelAction)
        
        let okayAction = UIAlertAction(title: "Onayla", style: .destructive){
            action in
            self.sepetYemeklerPresenterObj?.sepetYemeklerInteractor?.deleteTumSepet(list: self.sepetYemeklerListesi)
            let storyboard = UIStoryboard(name: "Main",bundle: nil)
            let VC = storyboard.instantiateViewController(withIdentifier: "mainPage")
            
            if let pageDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate,
               let window = pageDelegate.window {
                window.rootViewController = VC
            }
        }
        allertController.addAction(okayAction)
        self.present(allertController, animated: true)
    }
}

extension SepetYemeklerVC:PresenterToViewSepetYemeklerProtocol{
    func vieweVeriGonder(sepetYemeklerListesi: [SepetYemekler]) {
        self.sepetYemeklerListesi = sepetYemeklerListesi
        self.toplamHesapla()
        self.sepetYemeklerTableView.reloadData()
        DispatchQueue.main.async {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                if sepetYemeklerListesi.isEmpty {
                    let allertController = UIAlertController(title: "Sepetiniz Boş", message: "Ürün eklemek için ana sayfaya dönün.", preferredStyle: .alert)
                    
                    let cancelAction = UIAlertAction(title: "İptal", style: .cancel){
                        action in
                    }
                    allertController.addAction(cancelAction)
                    
                    let okayAction = UIAlertAction(title: "Tamam", style: .destructive){
                        action in
                        let storyboard = UIStoryboard(name: "Main",bundle: nil)
                        let VC = storyboard.instantiateViewController(withIdentifier: "mainPage")
                        
                        if let pageDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate,
                           let window = pageDelegate.window {
                            window.rootViewController = VC
                        }
                    }
                    allertController.addAction(okayAction)
                    self.present(allertController, animated: true)
                }
            }
        }
    }
}

extension SepetYemeklerVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return sepetYemeklerListesi.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let yemek = sepetYemeklerListesi[indexPath.row]
        let cell = sepetYemeklerTableView.dequeueReusableCell(withIdentifier: "sepetCell") as! SepetYemeklerFoodCell
        
        
        cell.indexPath = indexPath
        cell.fetchData(yemek: yemek)
        cell.cellpro = self
        let url = URL (string: ("http://kasimadalan.pe.hu/yemekler/resimler/\(yemek.yemek_resim_adi!)"))
        cell.sepetYemekImage.kf.setImage(with: url)
        cell.sepetYemekName.text = "\(yemek.yemek_adi!)"
        cell.sepetYemekPrice.text = "\(yemek.yemek_fiyat!) ₺"
        cell.sepetYemekAdet.text = "\(yemek.yemek_siparis_adet!)"
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let username = Auth.auth().currentUser!.email
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete"){
            (contextualAction,view,bool) in
            let sepetYemek = self.sepetYemeklerListesi[indexPath.row]
            let alert = UIAlertController(title: "Delete Action", message: "\(sepetYemek.yemek_adi!) silinsin mi?", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "İptal", style: .cancel)
            alert.addAction(cancelAction)
            
            let yesAction = UIAlertAction(title: "Sil", style: .destructive){
                action in
                self.sepetYemeklerPresenterObj?.delete(sepet_yemek_id: Int(sepetYemek.sepet_yemek_id!)!, kullanici_adi:username!)
            }
            alert.addAction(yesAction)
            
            self.present(alert, animated: true)
        }
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
}

extension SepetYemeklerVC: CellProtocol {
    func adetArttir(indexPath: IndexPath) {
        sepetYemeklerPresenterObj?.adetArttir(yemek: sepetYemeklerListesi[indexPath.row])
    }
    func adetAzalt(indexPath: IndexPath) {
        sepetYemeklerPresenterObj?.adetAzalt(yemek: sepetYemeklerListesi[indexPath.row])
        
    }
}
