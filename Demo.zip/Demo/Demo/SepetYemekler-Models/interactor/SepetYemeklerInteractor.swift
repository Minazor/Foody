import Foundation
import Alamofire
import FirebaseAuth

class SepetYemeklerInteractor: PresenterToInteractorSepetYemeklerProtocol {

    
   
    var sepetYemeklerListesi = [SepetYemekler]()
    var sepetYemeklerPresenter: InteractorToPresenterSepetYemeklerProtocol?
    
    func getTumSepetYemekler(kullanici_adi: String) {
       let username = Auth.auth().currentUser!.email
        let params = ["kullanici_adi": username!]
        
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettekiYemekleriGetir.php",method: .post, parameters: params).response{ response in
            if let data = response.data {
                do {
                    let sepetYemek = try JSONDecoder().decode(SepetYemeklerAnswers.self, from: data)
                    if let list = sepetYemek.sepet_yemekler {
                        self.sepetYemeklerPresenter?.presenteraVeriGonder(sepetYemeklerListesi: list.sorted(by: { $0.yemek_adi! < $1.yemek_adi! }))
                    }
                } catch {
                    self.sepetYemeklerPresenter?.presenteraVeriGonder(sepetYemeklerListesi: [])
                    print(error.localizedDescription)
                }
            }
        }
    }


    func deleteSepetYemek(sepet_yemek_id: Int,kullanici_adi:String) {
        let username = Auth.auth().currentUser!.email
        let params = ["sepet_yemek_id": String(sepet_yemek_id),
                      "kullanici_adi": username!]
        
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettenYemekSil.php",method: .post, parameters: params).response{ response in
            if let data = response.data {
                do {
                    let cevap = try JSONSerialization.jsonObject(with: data)
                    print(cevap)
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
       getTumSepetYemekler(kullanici_adi: username!)
    }
    
    func deleteTumSepet(list: [SepetYemekler]) {
        let username = Auth.auth().currentUser!.email
        for yemek in list {
            let params = ["sepet_yemek_id": yemek.sepet_yemek_id!,
                      "kullanici_adi": username!]
        
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettenYemekSil.php",method: .post, parameters: params).response{  response in
                if let data = response.data {
                    do {
                        let cevap = try JSONSerialization.jsonObject(with: data)
                        print(cevap)
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            }
        }
        getTumSepetYemekler(kullanici_adi: username!)
    }
 
    
    func adetArttir(yemek: SepetYemekler) {
        deleteSepetYemek(sepet_yemek_id: Int(yemek.sepet_yemek_id!)!, kullanici_adi: yemek.kullanici_adi!)
            let yeniAdet = Int(yemek.yemek_siparis_adet!)! + 1
            var request = URLRequest(url: URL(string: "http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php")!)
            request.httpMethod = "POST"
        let postString = "yemek_adi=\(yemek.yemek_adi!)&yemek_resim_adi=\(yemek.yemek_resim_adi!)&yemek_fiyat=\(yemek.yemek_fiyat!)&yemek_siparis_adet=\(String(yeniAdet))&kullanici_adi=\(yemek.kullanici_adi!)"
            request.httpBody = postString.data(using: .utf8)
            
            URLSession.shared.dataTask(with: request){data, response, error in
                do{
                    let response = try JSONSerialization.jsonObject(with: data!)
                    print(response)
                    self.getTumSepetYemekler(kullanici_adi: yemek.kullanici_adi!)
                }catch{
                    print(error.localizedDescription)
                }
            }.resume()
    }
    
    func adetAzalt(yemek: SepetYemekler) {
        if Int(yemek.yemek_siparis_adet!) != 1{
            deleteSepetYemek(sepet_yemek_id: Int(yemek.sepet_yemek_id!)!, kullanici_adi: yemek.kullanici_adi!)
            let yeniAdet = Int(yemek.yemek_siparis_adet!)! - 1
            var request = URLRequest(url: URL(string: "http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php")!)
            request.httpMethod = "POST"
            let postString = "yemek_adi=\(yemek.yemek_adi!)&yemek_resim_adi=\(yemek.yemek_resim_adi!)&yemek_fiyat=\(yemek.yemek_fiyat!)&yemek_siparis_adet=\(String(yeniAdet))&kullanici_adi=\(yemek.kullanici_adi!)"
            request.httpBody = postString.data(using: .utf8)
            
            URLSession.shared.dataTask(with: request){data, response, error in
                do{
                    let response = try JSONSerialization.jsonObject(with: data!)
                    print(response)
                    self.getTumSepetYemekler(kullanici_adi: yemek.kullanici_adi!)
                }catch{
                    print(error.localizedDescription)
                }
            }.resume()
        }else{
            deleteSepetYemek(sepet_yemek_id: Int(yemek.sepet_yemek_id!)!, kullanici_adi: yemek.kullanici_adi!)
        }
    }
}
