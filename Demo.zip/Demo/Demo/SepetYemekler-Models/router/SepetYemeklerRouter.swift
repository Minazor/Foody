import Foundation
class SepetYemeklerRouter : PresenterToRouterSepetYemeklerProtocol {
    static func createModule(ref: SepetYemeklerVC) {
        let presenter = SepetYemeklerPresenter()
        
        ref.sepetYemeklerPresenterObj = presenter
        ref.sepetYemeklerPresenterObj?.sepetYemeklerInteractor = SepetYemeklerInteractor()
        ref.sepetYemeklerPresenterObj?.sepetYemeklerView = ref
        ref.sepetYemeklerPresenterObj?.sepetYemeklerInteractor?.sepetYemeklerPresenter = presenter
    }
}
