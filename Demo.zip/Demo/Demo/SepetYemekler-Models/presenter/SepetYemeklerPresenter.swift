import Foundation
class SepetYemeklerPresenter : ViewToPresenterSepetYemeklerProtocol{
  
    
 
    var sepetYemeklerInteractor: PresenterToInteractorSepetYemeklerProtocol?
    var sepetYemeklerView: PresenterToViewSepetYemeklerProtocol?
    
    func getSepetYemekler(kullanici_adi:String) {
        sepetYemeklerInteractor?.getTumSepetYemekler(kullanici_adi: kullanici_adi)
    }
    func delete(sepet_yemek_id: Int,kullanici_adi: String) {
        sepetYemeklerInteractor?.deleteSepetYemek(sepet_yemek_id: sepet_yemek_id, kullanici_adi: kullanici_adi)
    }
    func adetArttir(yemek: SepetYemekler) {
        sepetYemeklerInteractor?.adetArttir(yemek: yemek)
    }
    func adetAzalt(yemek: SepetYemekler) {
        sepetYemeklerInteractor?.adetAzalt(yemek: yemek)
    }
    func deleteTumSepet(list: [SepetYemekler]){
        sepetYemeklerInteractor?.deleteTumSepet(list: list)
    }

    
}

extension SepetYemeklerPresenter : InteractorToPresenterSepetYemeklerProtocol {
    func presenteraVeriGonder(sepetYemeklerListesi: [SepetYemekler]) {
        sepetYemeklerView?.vieweVeriGonder(sepetYemeklerListesi: sepetYemeklerListesi)
    }
}
