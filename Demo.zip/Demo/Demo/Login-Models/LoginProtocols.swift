import Foundation

protocol ViewToPresenterLoginProtocol {
var loginInteractor: PresenterToInteractorLoginProtocol? { get set }
func login(email: String, password: String)
}

protocol PresenterToInteractorLoginProtocol {
func login(email: String, password: String)

}

protocol PresenterToRouterLoginProtocol {

static func createModule(ref: LoginVC)
}
