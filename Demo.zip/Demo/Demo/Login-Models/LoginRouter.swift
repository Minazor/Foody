import Foundation

class LoginRouter: PresenterToRouterLoginProtocol {
    
    static func createModule(ref: LoginVC) {
        ref.loginPresenterObj = LoginPresenter()
        ref.loginPresenterObj?.loginInteractor = LoginInteractor()
        
    }
}
