import UIKit
import FirebaseAuth

class LoginVC: UIViewController {

    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfSifre: UITextField!
    private var userIsLoggedIn = false
    
    var loginPresenterObj: ViewToPresenterLoginProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoginRouter.createModule(ref: self)

    }
    @IBAction func login(_ sender: Any) {
       logIn()
    }
    
    @IBAction func signUp(_ sender: Any) {
        performSegue(withIdentifier: "signUp", sender: nil)
    }
    
    func logIn() {
        if let email = tfEmail.text, let password = tfSifre.text{
            loginPresenterObj?.login(email: email, password: password)
        }
        checkUser()
    }
    
    func checkUser(){
        if Auth.auth().currentUser != nil {
            let storyboard = UIStoryboard(name: "Main",bundle: nil)
            let VC = storyboard.instantiateViewController(withIdentifier: "mainPage")
            
            if let pageDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate,
               let window = pageDelegate.window {
                window.rootViewController = VC
            }
        }
    }
}
