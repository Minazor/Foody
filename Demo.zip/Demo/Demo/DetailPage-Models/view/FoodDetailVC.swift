import UIKit
import FirebaseAuth
class FoodDetailVC: UIViewController {

    @IBOutlet weak var foodImage: UIImageView!
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodPrice: UILabel!
    @IBOutlet weak var azalt: UIButton!
    @IBOutlet weak var arttir: UIButton!
    
    @IBOutlet weak var labelAdet: UILabel!
    var food:Yemekler?
    
    var foodDetailPresenterObj : ViewToPresenterFoodDetailProtocol?
    var count = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        FoodDetailRouter.createModule(ref: self)
        
        if let f = food{
            let url = URL (string: ("http://kasimadalan.pe.hu/yemekler/resimler/\(f.yemek_resim_adi!)"))
            let data = try? Data(contentsOf: url!)
            foodImage.image = UIImage(data: data!)
            foodName.text = f.yemek_adi
            foodPrice.text = "\(f.yemek_fiyat!) ₺"
        }
    }
    
    @IBAction func sepeteEkleButton(_ sender: Any) {
        
        let username = Auth.auth().currentUser!.email
        if let f = food{
            foodDetailPresenterObj?.yemekEkle(yemek: f, count: count, kullanici_adi: username!)
        }
    }
    @IBAction func azalt(_ sender: Any) {
        if count <= 0 {
            azalt.isEnabled = false
        }else {
            count -= 1
            azalt.isEnabled = true
            labelAdet.text = String(count)
        }
    }
    @IBAction func arttir(_ sender: Any) {
        count += 1
        labelAdet.text = String(count)
        if count > 0 {
            azalt.isEnabled = true
        }
    }
}
