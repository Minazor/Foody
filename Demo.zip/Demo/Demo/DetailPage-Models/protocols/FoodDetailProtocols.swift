import Foundation
protocol ViewToPresenterFoodDetailProtocol {
    var foodDetailInteractor : PresenterToInteractorFoodDetailProtocol? {get set}
    func deleteSepetYemek(sepet_yemek_id:Int,kullanici_adi:String)
    func yemekEkle(yemek: Yemekler, count: Int, kullanici_adi: String)
}

protocol PresenterToInteractorFoodDetailProtocol {
    func deleteSepetYemek(sepet_yemek_id:Int,kullanici_adi:String)
    func sepeteYemekEkle(yemek: Yemekler, count: Int, kullanici_adi: String)
}

protocol PresenterToRouterFoodDetailProtocol {
    static func createModule(ref:FoodDetailVC)
}

