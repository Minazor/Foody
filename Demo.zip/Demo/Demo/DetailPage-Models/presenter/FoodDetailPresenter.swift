import Foundation
class FoodDetailPresenter : ViewToPresenterFoodDetailProtocol{
  
    
    
    var foodDetailInteractor: PresenterToInteractorFoodDetailProtocol?

    func yemekEkle(yemek: Yemekler, count: Int, kullanici_adi: String) {
        foodDetailInteractor?.sepeteYemekEkle(yemek: yemek, count: count, kullanici_adi: kullanici_adi)
    }
    func deleteSepetYemek(sepet_yemek_id:Int,kullanici_adi:String){
        foodDetailInteractor?.deleteSepetYemek(sepet_yemek_id: sepet_yemek_id, kullanici_adi: kullanici_adi)
    }
    
}
