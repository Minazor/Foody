import Foundation
import Alamofire
import FirebaseAuth
class FoodDetailInteractor: PresenterToInteractorFoodDetailProtocol {

var sepetYemeklerListesi = [SepetYemekler]()
    
    let username = Auth.auth().currentUser!.email
    func sepeteYemekEkle(yemek: Yemekler, count: Int, kullanici_adi: String) {
        let params = ["kullanici_adi": username]
            AF.request("http://kasimadalan.pe.hu/yemekler/sepettekiYemekleriGetir.php",method: .post, parameters: params).response{ response in
            if let data = response.data {
                var sum = Int(count)
                do {
                    let sepetYemek = try JSONDecoder().decode(SepetYemeklerAnswers.self, from: data)
                    if let list = sepetYemek.sepet_yemekler {
                        for y in list {
                            if y.yemek_adi == yemek.yemek_adi {
                                sum += Int(y.yemek_siparis_adet!)!
                                self.deleteSepetYemek(sepet_yemek_id: Int(y.sepet_yemek_id!)!, kullanici_adi: y.kullanici_adi!)
                            }
                        }
                    }
                } catch {
                    print(error.localizedDescription)
                }
                self.yeniYemekEkle(yemek: yemek, count: sum, kullanici_adi: kullanici_adi)
            }
        }
        self.getTumSepetYemekler(kullanici_adi: kullanici_adi)
    }
    
    func yeniYemekEkle(yemek: Yemekler, count: Int, kullanici_adi: String){
        
        let username = Auth.auth().currentUser!.email
        var request = URLRequest(url: URL(string: "http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php")!)
        request.httpMethod = "POST"
            let postString = "yemek_adi=\(yemek.yemek_adi!)&yemek_resim_adi=\(yemek.yemek_resim_adi!)&yemek_fiyat=\(yemek.yemek_fiyat!)&yemek_siparis_adet=\(count)&kullanici_adi=\(username!)"
        request.httpBody = postString.data(using: .utf8)
    
        URLSession.shared.dataTask(with: request){data, response, error in
            do{
                let response = try JSONSerialization.jsonObject(with: data!)
                print(response)
            }catch{
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    func deleteSepetYemek(sepet_yemek_id: Int,kullanici_adi:String) {
        
        let username = Auth.auth().currentUser!.email
        var request = URLRequest(url: URL(string: "http://kasimadalan.pe.hu/yemekler/sepettenYemekSil.php")!)
        request.httpMethod = "POST"
        let postString = "sepet_yemek_id=\(sepet_yemek_id)&kullanici_adi=\(username!)"
        request.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request){data, response, error in
            do{
                
                let response = try JSONSerialization.jsonObject(with: data!)
                print(response)
            }catch{
                print(String(describing: error))
            }
        }.resume()
    }
    
    func getTumSepetYemekler(kullanici_adi: String) {
        
       let username = Auth.auth().currentUser!.email
       let params = ["kullanici_adi": username!]
        
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettekiYemekleriGetir.php",method: .post, parameters: params).response{ response in
            if let data = response.data {
                do {
                    let sepetYemek = try JSONDecoder().decode(SepetYemeklerAnswers.self, from: data)
                    if let list = sepetYemek.sepet_yemekler {
                        self.sepetYemeklerListesi = list
                    }
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
      
    }
}

