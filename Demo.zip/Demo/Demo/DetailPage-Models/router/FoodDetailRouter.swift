
import Foundation
class FoodDetailRouter : PresenterToRouterFoodDetailProtocol {
    
    static func createModule(ref: FoodDetailVC) {
        ref.foodDetailPresenterObj = FoodDetailPresenter()
        ref.foodDetailPresenterObj?.foodDetailInteractor = FoodDetailInteractor()
    }
}
