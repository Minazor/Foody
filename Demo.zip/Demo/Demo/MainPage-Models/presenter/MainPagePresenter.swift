
import Foundation

class MainPagePresenter: ViewToPresenterMainPageProtocol {
    var mainPageInteractor: PresenterToInteractorMainPageProtocol?
    var mainPageView: PresenterToViewMainPageProtocol?
    
    func getYemekler() {
        mainPageInteractor?.getTumYemekler()
    }
    func searchYemek(searchText: String) {
        mainPageInteractor?.searchYemek(searchText: searchText)
    }
}

extension MainPagePresenter: InteractorToPresenterMainPageProtocol {
    func presenteraVeriGonder(yemeklerListesi: [Yemekler]) {
        mainPageView?.vieweVeriGonder(yemeklerListesi: yemeklerListesi)
    }
}
