
import Foundation

protocol ViewToPresenterMainPageProtocol {
    var mainPageInteractor:PresenterToInteractorMainPageProtocol? {get set}
    var mainPageView:PresenterToViewMainPageProtocol? {get set}
    
    func getYemekler()
}

protocol PresenterToInteractorMainPageProtocol {
    var mainPagePresenter:InteractorToPresenterMainPageProtocol? {get set}
    
    func getTumYemekler()
    func searchYemek(searchText: String)
 
}

protocol InteractorToPresenterMainPageProtocol{
    func presenteraVeriGonder(yemeklerListesi:[Yemekler])
}

protocol PresenterToViewMainPageProtocol {
    func vieweVeriGonder(yemeklerListesi:[Yemekler])
}

protocol PresenterToRouterMainPageProtocol{
    static func createModule(ref:MainPageVC)
}
