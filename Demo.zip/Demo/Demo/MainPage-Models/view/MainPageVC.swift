
import UIKit
import Kingfisher

import FirebaseAuth

class MainPageVC: UIViewController, UISearchBarDelegate {
    
    
    @IBOutlet weak var foodTableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var pageControl: UIPageControl!
    
    @IBOutlet weak var sepetButton: UIBarButtonItem!
    var searchActive:Bool = false
    
    var yemeklerListesi = [Yemekler]()
    var filteredYemekler = [Yemekler]()
    
    var slide = ["foody","foody2"]
    
    var mainPagePresenterObj: ViewToPresenterMainPageProtocol?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        foodTableView.delegate = self
        foodTableView.dataSource = self
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        searchBar.delegate = self
        
        
        filteredYemekler = yemeklerListesi
        searchBar.returnKeyType = UIReturnKeyType.done
               definesPresentationContext=true
        MainPageRouter.createModule(ref: self)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        mainPagePresenterObj?.getYemekler()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetail"{
            if let yemek = sender as? Yemekler{
                let goToVC = segue.destination as! FoodDetailVC
                goToVC.food = yemek
            }
        }
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        searchText.isEmpty ? mainPagePresenterObj?.getYemekler() : mainPagePresenterObj?.mainPageInteractor?.searchYemek(searchText: searchText)
        
    }
}

extension MainPageVC : PresenterToViewMainPageProtocol{
    func vieweVeriGonder(yemeklerListesi: [Yemekler]) {
        self.yemeklerListesi = yemeklerListesi
        DispatchQueue.main.async {
            self.foodTableView.reloadData()
        }
    }
}

extension MainPageVC : UITableViewDelegate, UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
            return yemeklerListesi.count
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 15.0
        }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let yemek = yemeklerListesi[indexPath.row]
            let cell = foodTableView.dequeueReusableCell(withIdentifier: "foodCell") as! MainPageFoodCell
            let url = URL (string: ("http://kasimadalan.pe.hu/yemekler/resimler/\(yemek.yemek_resim_adi!)"))
           
            
            cell.foodImage.kf.setImage(with: url)
            cell.foodName.text = "\(yemek.yemek_adi!)"
            cell.foodPrice.text = "\(yemek.yemek_fiyat!) ₺"
        
            
            return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
            let yemek = yemeklerListesi[indexPath.row]
            performSegue(withIdentifier: "toDetail", sender: yemek)
            tableView.deselectRow(at: indexPath, animated: true)
     
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
}

extension MainPageVC : UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
          return slide.count
      
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let slide = slide[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "slideCell", for: indexPath) as! CollectionViewCell
        cell.image.image = UIImage(named: slide)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        pageControl.currentPage = indexPath.row
    }
}
