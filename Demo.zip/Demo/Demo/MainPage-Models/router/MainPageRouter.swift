

import Foundation
class MainPageRouter : PresenterToRouterMainPageProtocol {
    static func createModule(ref: MainPageVC) {
        let presenter = MainPagePresenter()
        
        ref.mainPagePresenterObj = presenter
        ref.mainPagePresenterObj?.mainPageInteractor = MainPageInteractor()
        ref.mainPagePresenterObj?.mainPageView = ref
        ref.mainPagePresenterObj?.mainPageInteractor?.mainPagePresenter = presenter
    }
}
