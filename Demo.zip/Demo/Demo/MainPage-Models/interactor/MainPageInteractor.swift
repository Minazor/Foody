import Foundation
import Alamofire
class MainPageInteractor: PresenterToInteractorMainPageProtocol {

    
    
    var mainPagePresenter: InteractorToPresenterMainPageProtocol?
    
    func getTumYemekler() {
        
        AF.request("http://kasimadalan.pe.hu/yemekler/tumYemekleriGetir.php",method: .get).response {
            response in
            if let data = response.data {
                do {
                    let response = try JSONDecoder().decode(YemeklerAnswers.self, from: data)
                    if let list = response.yemekler {
                        self.mainPagePresenter?.presenteraVeriGonder(yemeklerListesi: list)
                    }
                } catch {
                    print(String(describing: error))
                }
            }
        }
    }
    
    func searchYemek(searchText: String) {
        AF.request("http://kasimadalan.pe.hu/yemekler/tumYemekleriGetir.php",method: .get).response { response in
            
            if let data = response.data {
                do {
                    let yemekResponse = try JSONDecoder().decode(YemeklerAnswers.self, from: data)
                    
                    if let list = yemekResponse.yemekler {
                        var araYemeklerListesi = [Yemekler]()
                        for yemek in list {
                            
                            if yemek.yemek_adi!.contains(searchText) {
                                araYemeklerListesi.append(yemek)
                            }
                        }
                        self.mainPagePresenter?.presenteraVeriGonder(yemeklerListesi: araYemeklerListesi)
                    }
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
    }
}
